<?php
// Database connection for InfinityFree

$db_hostname = "sql112.infinityfree.com";
$db_username = "if0_38872964";
$db_password = "Ganesh000"; // Your vPanel password
$db_name     = "if0_38872964_webdevelopment";

$con = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

// Optional: Suppress errors in production
// if (!$con) { die("Connection failed: " . mysqli_connect_error()); }
?>
